#include "str.h"

void csv_para_binario1(string_t csv, string_t binario_saida);
void csv_para_binario2(string_t csv, string_t binario_saida);
void funcionalidade1(string_t tipo_do_arquivo, string_t csv, string_t binario_saida);
void funcionalidade2(string_t tipo_do_arquivo, string_t binario_entrada);
void funcionalidade4(string_t tipo_de_arquivo, string_t binario_entrada, int RRN);