#include "indice.h"

// Função que executa o Heapsort nos registros de um índice em RAM
void Heapsort(indice_t *indice);